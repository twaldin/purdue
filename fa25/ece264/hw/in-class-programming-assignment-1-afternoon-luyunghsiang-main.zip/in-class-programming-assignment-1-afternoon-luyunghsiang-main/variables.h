// Do NOT modify this file

#ifndef __VARIABLES_H__
#define __VARIABLES_H__

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char* declare_variables(int number, char character);

#endif
